#pragma once

#include "BoostTestFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::BoostTestFakeit::getInstance();
