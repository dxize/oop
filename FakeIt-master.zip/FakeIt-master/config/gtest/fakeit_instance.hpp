#pragma once

#include "GTestFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::GTestFakeit::getInstance();
