#pragma once

#include "CuteFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::CuteFakeit::getInstance();
