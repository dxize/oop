#pragma once

#include "DoctestFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::DoctestFakeit::getInstance();
