#pragma once

#include "MettleFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::MettleFakeit::getInstance();
